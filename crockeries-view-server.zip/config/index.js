const UPLOAD_USER_IMG_DIRECTORY = "public/images/users";
const MAX_FILE_SIZE = 2097152;
const ALLOW_FILE_TYPES = ['jpg', "jpeg", "png"]


module.exports = {
    UPLOAD_USER_IMG_DIRECTORY,
    MAX_FILE_SIZE,
    ALLOW_FILE_TYPES
}